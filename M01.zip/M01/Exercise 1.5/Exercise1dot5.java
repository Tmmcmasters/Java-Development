public class Exercise1dot5 {
    public static void main(String[] args) {
        //Displays the math solution
        double mathSolution = ((9.5 * 4.5) - ( 2.5 * 3)) / (45.5 - 3.5); //variable storing the math problem
        System.out.println(mathSolution); //outputs the math solution
    }
}
