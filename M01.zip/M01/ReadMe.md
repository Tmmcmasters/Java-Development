EXERCISE 1.5 \/\/\/\/\/\/

1.5 (COMPUTE EXPRESSIONS) Write a program that displays the result of

9.5 x 4.5 - 2.5 x 3 / 45.5 -3.5

EXERCISE 2.3 \/\/\/\/\/\/

2.3 (CONVERT FEET INTO METERS) Write a program that reads a number in feet, converts it to meters, and displays the result. One foot is 0.305 meter. Here is a sample run:



Enter a value for feet: 16.5 
16.5 feet is 5.0325 meters

EXERCISE 3.15 \/\/\/\/\/\/

**3.15 (GAME: LOTTERY) Revise Listing 3.8, Lottery.java, to generate a lottery of a three-digit integer. The program prompts the user to enter a three-digit integer and determines whether the user wins according to the following rules:

If the user input matches the lottery number in the exact order, the award is $10,000.

If all digits in the user input match all digits in the lottery number, the award is $3,000.

If one digit in the user input matches a digit in the lottery number, the award is $1,000.