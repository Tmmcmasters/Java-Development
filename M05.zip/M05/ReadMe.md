# Exercise 12.9:
*12.9 (BINARYFORMATEXCEPTION) Exercise 12.7 implements the bin2Dec method to throw a BinaryFormatException if the string is not a binary string. Define a custom exception called BinaryFormatException. Implement the bin2Dec method to throw a BinaryFormatException if the string is not a binary string.

*Reference to 12.7:
*12.9 (BINARYFORMATEXCEPTION) Exercise 12.7 implements the bin2Dec method to throw a BinaryFormatException if the string is not a binary string. Define a custom exception called BinaryFormatException. Implement the bin2Dec method to throw a BinaryFormatException if the string is not a binary string.
# Exercise 13.9
*13.9 (ENABLE CIRCLE COMPARABLE) Rewrite the Circle class in Listing 13.2 to extend GeometricObject and implement the Comparable interface. Override the equals method in the Object class. Two Circle objects are equal if their radii are the same. Draw the UML diagram that involves Circle, GeometricObject, and Comparable.

# Exercise 13.15
*13.15 (USE BIGINTEGER FOR THE RATIONAL CLASS) Redesign and implement the Rational class in Listing 13.13 using BigInteger for the numerator and denominator. Write a test program that prompts the user to enter two rational ­numbers and ­display the results as shown in the following sample run:



Enter the first rational number: 3 454 
Enter the second rational number: 7 2389 
3/454 + 7/2389 = 10345/1084606
3/454 – 7/2389 = 3989/1084606
3/454 * 7/2389 = 21/1084606
3/454 / 7/2389 = 7167/3178
7/2389 is 0.0029300962745918793