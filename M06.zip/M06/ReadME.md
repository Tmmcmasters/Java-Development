# Exercise 14.1
14.1 (DISPLAY IMAGES) Write a program that displays four images in a grid pane, as shown in Figure 14.43a.
# Exercise 15.5
*15.5 (CREATE AN INVESTMENT-VALUE CALCULATOR) Write a program that calculates the future value of an investment at a given interest rate for a specified number of years. The formula for the calculation is

futureValue = investmentAmount * (1 + monthlyInterestRate)years*12
Use text fields for the investment amount, number of years, and annual interest rate. Display the future amount in a text field when the user clicks the Calculate button, as shown in Figure 15.27b.
# Exercise 19.5
19.5 (MAXIMUM ELEMENT IN AN ARRAY) Implement the following method that returns the maximum element in an array:


public static <E extends Comparable<E>> E max(E[] list)


Write a test program that prompts the user to enter 10 integers, invokes this method to find the max, and displays the maximum number.